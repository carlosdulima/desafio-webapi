﻿namespace Softplan.CalculaJuros.Infra.Configuration
{
    public class ApiCatalogo
    {
        public const string TAXA_JUROS = "TaxaJuros";
    }
}
