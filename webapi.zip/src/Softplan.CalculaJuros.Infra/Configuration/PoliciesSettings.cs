﻿namespace Softplan.CalculaJuros.Infra.Configuration
{
    public class PoliciesSettings
    {
        public int Retry { get; set; }
    }
}
