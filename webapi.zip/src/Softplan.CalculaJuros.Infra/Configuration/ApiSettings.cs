﻿namespace Softplan.CalculaJuros.Infra.Configuration
{
    public class ApiSettings
    {
        public string Name { get; set; }
        public string Url { get; set; }
        public PoliciesSettings PoliciesSettings { get; set; }
    }
}
