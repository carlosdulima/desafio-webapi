﻿namespace Softplan.CalculaJuros.ApplicationCore.Command
{
    public class CalculaJurosCommand
    {
        public decimal ValorInicial { get; set; }
        public int Meses { get; set; }
    }
}
